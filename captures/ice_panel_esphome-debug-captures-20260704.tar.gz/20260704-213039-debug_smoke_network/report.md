# Ice Maker Debug Capture Analysis

This report compares old 1 kHz Arduino sniffer captures with ESPHome debug firmware D-frame captures.
ADC values are relative floating-GPIO signatures, not real panel voltages.

## Old Sniffer Baseline

### old_standby (standby)

- Rows: `99415`; duration: `99.8s`; source: `old A samples`
- Top signatures: `MHMHH` 72.2%, `0HMHH` 5.9%, `MMMHM` 5.6%, `MHHHH` 4.6%, `MMMMH` 4.3%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.0% | 72.3% | 2012.0 | 547.6 | -6.0 | -2196.0 |
| 0.5s | 0.0% | 72.1% | 2057.0 | 516.4 | -6.0 | -2196.0 |
| 1s | 0.0% | 72.1% | 4095.0 | 517.7 | -6.0 | -2196.0 |
| 2s | 0.0% | 72.2% | 4095.0 | 514.0 | -6.0 | -2196.0 |
| 4s | 0.0% | 72.3% | 4095.0 | 585.5 | -6.0 | -2196.5 |
| 8s | 0.0% | 72.2% | 4095.0 | 586.4 | -6.0 | -2196.5 |
| 16s | 0.0% | 72.2% | 4095.0 | 587.2 | -6.0 | -2196.5 |

### old_large (large)

- Rows: `119646`; duration: `120.2s`; source: `old A samples`
- Top signatures: `0HHHH` 83.6%, `H0H0H` 5.9%, `MMMHM` 5.2%, `H0HHH` 0.7%, `0HHHM` 0.7%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 83.6% | 0.0% | 4095.0 | 1131.1 | -4095.0 | -4095.0 |
| 0.5s | 83.6% | 0.0% | 4095.0 | 1124.3 | -4095.0 | -4095.0 |
| 1s | 83.6% | 0.0% | 4095.0 | 1126.4 | -4095.0 | -4095.0 |
| 2s | 83.6% | 0.0% | 4095.0 | 1126.5 | -4095.0 | -4095.0 |
| 4s | 83.6% | 0.0% | 4095.0 | 1126.6 | -4095.0 | -4095.0 |
| 8s | 83.6% | 0.0% | 4095.0 | 1126.0 | -4095.0 | -4095.0 |
| 16s | 83.6% | 0.0% | 4095.0 | 1126.6 | -4095.0 | -4095.0 |

### old_small (small)

- Rows: `70442`; duration: `70.8s`; source: `old A samples`
- Top signatures: `MHMHH` 58.2%, `0HHHH` 13.2%, `MMMHM` 5.1%, `HHMMH` 4.8%, `MHHHH` 3.8%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.0% | 68.3% | 4095.0 | 770.3 | -5.0 | -2192.0 |
| 0.5s | 0.0% | 68.9% | 4095.0 | 766.9 | -5.0 | -2192.0 |
| 1s | 0.0% | 69.2% | 4095.0 | 763.9 | -5.0 | -2192.0 |
| 2s | 0.0% | 69.6% | 4095.0 | 753.9 | -5.0 | -2192.0 |
| 4s | 0.0% | 69.8% | 4095.0 | 754.9 | -5.0 | -2192.0 |
| 8s | 0.0% | 69.0% | 4095.0 | 761.5 | -4.5 | -2192.5 |
| 16s | 0.0% | 68.7% | 4095.0 | 768.1 | -4.5 | -2192.0 |

### old_small_to_large (mixed)

- Rows: `123532`; duration: `124.1s`; source: `old A samples`
- Top signatures: `MHMHH` 53.2%, `0HHHH` 20.5%, `MMMHM` 5.3%, `HHMMH` 4.4%, `0HMHH` 3.4%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.0% | 69.1% | 4095.0 | 773.4 | -6.0 | -2194.0 |
| 0.5s | 0.0% | 69.5% | 4095.0 | 758.4 | -6.0 | -2194.0 |
| 1s | 0.0% | 70.1% | 4095.0 | 754.1 | -6.0 | -2194.0 |
| 2s | 0.0% | 70.2% | 4095.0 | 750.8 | -5.0 | -2194.0 |
| 4s | 0.0% | 69.9% | 4095.0 | 749.4 | -5.0 | -2194.0 |
| 8s | 0.0% | 70.1% | 4095.0 | 751.4 | -5.0 | -2194.0 |
| 16s | 0.0% | 70.5% | 4095.0 | 748.3 | -5.0 | -2193.0 |

## ESPHome Debug Captures

### 20260704-213039-debug_smoke_network (unknown)

- Rows: `13`; duration: `12.1s`; source: `debug D-frames`
- Backend: `ESP-IDF adc_continuous DMA`
- Median frame sample rate: `8278.0 Hz`; median ADC error: `0.000%`
- Debug frame period: median `1.007s`

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 1.1% | 74.4% | 0.0 | 514.0 | -222.9 | -2081.6 |
| 0.5s | 1.1% | 74.4% | 0.0 | 514.0 | -222.9 | -2081.6 |
| 1s | 1.1% | 74.4% | 0.0 | 514.0 | -222.9 | -2081.6 |
| 2s | 1.0% | 74.7% | 35.5 | 544.2 | -206.0 | -2067.2 |
| 4s | 1.1% | 74.4% | 116.2 | 517.7 | -222.1 | -2078.7 |
| 8s | 1.1% | 74.5% | 116.2 | 514.0 | -222.9 | -2081.6 |
| 16s | n/a | n/a | n/a | n/a | n/a | n/a |

Note: debug captures are currently exported as firmware-side summary frames.
Windows shorter than the debug frame period are therefore limited by the emitted frame cadence.

## Interpretation Checklist

- If debug `Sample Rate` is near `10000 Hz` per P1-P5 frame and `ADC Error Rate` is low, sampling performance improved over the old 1 kHz sniffer.
- If standby and small both keep `MHMHH` dominant, prefer `P1 stddev`, `P1-P4`, and blink-window features over signature-only detection.
- If short windows still overlap heavily, the limiting factor is likely the floating direct-GPIO electrical interface rather than ESP32-C3 sampling throughput.
