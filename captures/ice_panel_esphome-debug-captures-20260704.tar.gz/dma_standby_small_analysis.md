# Ice Maker Debug Capture Analysis

This report compares old 1 kHz Arduino sniffer captures with ESPHome debug firmware D-frame captures.
ADC values are relative floating-GPIO signatures, not real panel voltages.

## Old Sniffer Baseline

### old_standby (standby)

- Rows: `99415`; duration: `99.8s`; source: `old A samples`
- Top signatures: `MHMHH` 72.2%, `0HMHH` 5.9%, `MMMHM` 5.6%, `MHHHH` 4.6%, `MMMMH` 4.3%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.0% | 72.3% | 2012.0 | 547.6 | -6.0 | -2196.0 |
| 0.5s | 0.0% | 72.1% | 2057.0 | 516.4 | -6.0 | -2196.0 |
| 1s | 0.0% | 72.1% | 4095.0 | 517.7 | -6.0 | -2196.0 |
| 2s | 0.0% | 72.2% | 4095.0 | 514.0 | -6.0 | -2196.0 |
| 4s | 0.0% | 72.3% | 4095.0 | 585.5 | -6.0 | -2196.5 |
| 8s | 0.0% | 72.2% | 4095.0 | 586.4 | -6.0 | -2196.5 |
| 16s | 0.0% | 72.2% | 4095.0 | 587.2 | -6.0 | -2196.5 |

### old_large (large)

- Rows: `119646`; duration: `120.2s`; source: `old A samples`
- Top signatures: `0HHHH` 83.6%, `H0H0H` 5.9%, `MMMHM` 5.2%, `H0HHH` 0.7%, `0HHHM` 0.7%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 83.6% | 0.0% | 4095.0 | 1131.1 | -4095.0 | -4095.0 |
| 0.5s | 83.6% | 0.0% | 4095.0 | 1124.3 | -4095.0 | -4095.0 |
| 1s | 83.6% | 0.0% | 4095.0 | 1126.4 | -4095.0 | -4095.0 |
| 2s | 83.6% | 0.0% | 4095.0 | 1126.5 | -4095.0 | -4095.0 |
| 4s | 83.6% | 0.0% | 4095.0 | 1126.6 | -4095.0 | -4095.0 |
| 8s | 83.6% | 0.0% | 4095.0 | 1126.0 | -4095.0 | -4095.0 |
| 16s | 83.6% | 0.0% | 4095.0 | 1126.6 | -4095.0 | -4095.0 |

### old_small (small)

- Rows: `70442`; duration: `70.8s`; source: `old A samples`
- Top signatures: `MHMHH` 58.2%, `0HHHH` 13.2%, `MMMHM` 5.1%, `HHMMH` 4.8%, `MHHHH` 3.8%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.0% | 68.3% | 4095.0 | 770.3 | -5.0 | -2192.0 |
| 0.5s | 0.0% | 68.9% | 4095.0 | 766.9 | -5.0 | -2192.0 |
| 1s | 0.0% | 69.2% | 4095.0 | 763.9 | -5.0 | -2192.0 |
| 2s | 0.0% | 69.6% | 4095.0 | 753.9 | -5.0 | -2192.0 |
| 4s | 0.0% | 69.8% | 4095.0 | 754.9 | -5.0 | -2192.0 |
| 8s | 0.0% | 69.0% | 4095.0 | 761.5 | -4.5 | -2192.5 |
| 16s | 0.0% | 68.7% | 4095.0 | 768.1 | -4.5 | -2192.0 |

### old_small_to_large (mixed)

- Rows: `123532`; duration: `124.1s`; source: `old A samples`
- Top signatures: `MHMHH` 53.2%, `0HHHH` 20.5%, `MMMHM` 5.3%, `HHMMH` 4.4%, `0HMHH` 3.4%

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.0% | 69.1% | 4095.0 | 773.4 | -6.0 | -2194.0 |
| 0.5s | 0.0% | 69.5% | 4095.0 | 758.4 | -6.0 | -2194.0 |
| 1s | 0.0% | 70.1% | 4095.0 | 754.1 | -6.0 | -2194.0 |
| 2s | 0.0% | 70.2% | 4095.0 | 750.8 | -5.0 | -2194.0 |
| 4s | 0.0% | 69.9% | 4095.0 | 749.4 | -5.0 | -2194.0 |
| 8s | 0.0% | 70.1% | 4095.0 | 751.4 | -5.0 | -2194.0 |
| 16s | 0.0% | 70.5% | 4095.0 | 748.3 | -5.0 | -2193.0 |

## ESPHome Debug Captures

### 20260704-213218-debug_standby_dma (standby)

- Rows: `88`; duration: `87.6s`; source: `debug D-frames`
- Backend: `ESP-IDF adc_continuous DMA`
- Median frame sample rate: `8233.5 Hz`; median ADC error: `0.000%`
- Debug frame period: median `1.007s`

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 1.0% | 74.6% | 0.0 | 591.9 | -191.3 | -2052.5 |
| 0.5s | 1.0% | 74.6% | 0.0 | 591.9 | -191.3 | -2052.5 |
| 1s | 1.0% | 74.6% | 0.0 | 591.9 | -191.3 | -2052.5 |
| 2s | 1.1% | 74.6% | 16.1 | 632.5 | -169.1 | -2033.7 |
| 4s | 1.1% | 74.6% | 99.5 | 537.2 | -212.8 | -2072.1 |
| 8s | 1.0% | 74.6% | 103.6 | 534.5 | -212.8 | -2072.8 |
| 16s | 1.0% | 74.6% | 104.2 | 534.5 | -212.8 | -2073.3 |

### 20260704-222441-debug_small_dma (small)

- Rows: `88`; duration: `87.6s`; source: `debug D-frames`
- Backend: `ESP-IDF adc_continuous DMA`
- Median frame sample rate: `8227.0 Hz`; median ADC error: `0.000%`
- Debug frame period: median `1.007s`

| Window | ratio 0HHHH median | ratio MHMHH median | P1 amp median | P1 stddev median | P1-P3 median | P1-P4 median |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25s | 0.9% | 71.8% | 0.0 | 772.9 | -86.9 | -2003.5 |
| 0.5s | 0.9% | 71.8% | 0.0 | 772.9 | -86.9 | -2003.5 |
| 1s | 0.9% | 71.8% | 0.0 | 772.9 | -86.9 | -2003.5 |
| 2s | 0.9% | 71.8% | 4.5 | 772.1 | -87.8 | -2002.0 |
| 4s | 0.9% | 71.9% | 11.4 | 771.0 | -88.0 | -2001.0 |
| 8s | 0.9% | 72.0% | 16.5 | 770.7 | -87.9 | -2001.5 |
| 16s | 0.9% | 72.0% | 21.9 | 769.4 | -88.9 | -2000.9 |

## Standby vs Small Discriminator Hints

These thresholds are derived from the current debug captures only. Treat them as candidates for the main classifier, not universal constants yet.

| Feature | Standby p10/p50/p90 | Small p10/p50/p90 | Best rule for Small | Accuracy |
|---|---:|---:|---|---:|
| `p1_stddev` | 459.8/531.9/667.1 | 761.7/772.8/796.5 | `p1_stddev > 683.3` | 100.0% (0 errors) |
| `delta_p1_p3` | -248.5/-216.8/-144.9 | -95.9/-86.9/-72.6 | `delta_p1_p3 > -136.6` | 100.0% (0 errors) |
| `p2_stddev` | 738.5/746.1/756.1 | 549.3/562.1/584.4 | `p2_stddev < 724.1` | 100.0% (0 errors) |
| `delta_p2_p4` | -170.2/-158.1/-150.0 | -31.7/-26.2/-20.8 | `delta_p2_p4 > -146.5` | 100.0% (0 errors) |
| `delta_p5_p2` | 148.8/155.4/163.2 | -3.0/1.6/7.2 | `delta_p5_p2 < 143.4` | 100.0% (0 errors) |

Practical first-pass rule: keep `MHMHH` as the shared running/standby candidate, then separate Small from Standby with `p1_stddev`, `delta_p1_p3`, or `delta_p2_p4` over a 1-2 second frame window.

Note: debug captures are currently exported as firmware-side summary frames.
Windows shorter than the debug frame period are therefore limited by the emitted frame cadence.

## Interpretation Checklist

- If debug `Sample Rate` is near `10000 Hz` per P1-P5 frame and `ADC Error Rate` is low, sampling performance improved over the old 1 kHz sniffer.
- If standby and small both keep `MHMHH` dominant, prefer `P1 stddev`, `P1-P4`, and blink-window features over signature-only detection.
- If short windows still overlap heavily, the limiting factor is likely the floating direct-GPIO electrical interface rather than ESP32-C3 sampling throughput.
